/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author Raphael
 */
public class Substancias {
    private String cod_subs;
    private String nome_subs;

    public String getCod_subs() {
        return cod_subs;
    }

    public void setCod_subs(String cod_subs) {
        this.cod_subs = cod_subs;
    }

    public String getNome_subs() {
        return nome_subs;
    }

    public void setNome_subs(String nome_subs) {
        this.nome_subs = nome_subs;
    }
}
